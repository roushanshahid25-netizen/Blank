﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using NaatsWebApp.Models;


namespace NaatsWebApp.Controllers
{
     
    public class NaatkhuwaanController : Controller
    {
        DBAccess db=new DBAccess();
        [HttpGet]
        public IActionResult AllNK()
        { //Second question of paper
            List<NaatKhuwaan> nklist = new List<NaatKhuwaan>();
            db.OpenConnection();
            string q = "select nkid,name,country," +
                "gender,email,isalive from NaatKhuwaan";
            SqlDataReader sdr = db.getData(q);
            while (sdr.Read())
            {
                NaatKhuwaan nk = new NaatKhuwaan();
                nk.nkid = sdr["nkid"].ToString();
                nk.name = sdr["name"].ToString();
                nk.country = sdr["country"].ToString();
                nk.gender = Char.Parse(sdr["gender"].ToString());
                nk.email = sdr["email"].ToString();
                nk.isalive = bool.Parse(sdr["isalive"].ToString());
                nklist.Add(nk);
            }
            sdr.Close();
            db.CloseConnection();
            return View(nklist);
        }
        [HttpGet]
        public IActionResult AddNK()
        {
          //  NaatKhuwaan nk=new NaatKhuwaan();
           // nk.nkid = "Default";
           return View();
        }
        [HttpPost]
        public IActionResult AddNK(NaatKhuwaan nk)
        {
            if (ModelState.IsValid)
            {
                nk.nkid = nk.email.Split('@')[0];
                string q = $"INSERT INTO NaatKhuwaan VALUES ('{nk.nkid}', '{nk.name}', '{nk.country}', " +
                           $"'{nk.gender}','{nk.isalive}', '{nk.email}','{nk.password}')";

                db.OpenConnection();
                db.IUD(q);
                db.CloseConnection();

                ViewBag.resp = "Registered Successfully";
                return View(nk);

            }
            return View(nk);
        }

        [HttpGet]
        public IActionResult DeleteNK(string nid)
        {
            string q = $"Delete from naatkhuwaan where nkid='{nid}'";
            db.OpenConnection();
            db.IUD(q);
            db.CloseConnection();
            return RedirectToAction("AllNK");
        }


    }
}

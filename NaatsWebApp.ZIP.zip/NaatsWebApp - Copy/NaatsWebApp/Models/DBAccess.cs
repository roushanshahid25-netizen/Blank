﻿using Microsoft.Data.SqlClient;
using System.Data;
using System.Data.SqlClient;

namespace NaatsWebApp.Models
{
    public class DBAccess
    {
        static string constr = @"server=DESKTOP-I56V1CQ\SQLEXPRESS;
        initial catalog=NaatsDB; integrated security=true; trust server certificate=true; ";
        public SqlConnection con=new SqlConnection(constr);
        public SqlCommand cmd=null;
        public SqlDataReader sdr=null;

      public void OpenConnection()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }
        public void CloseConnection()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
        public void IUD(string query)
        {
            cmd=new SqlCommand(query,con);
            cmd.ExecuteNonQuery();

        } 
        public SqlDataReader getData(string query)
        {
            cmd = new SqlCommand(query, con);
            sdr=cmd.ExecuteReader();
            return sdr;
        }

    }
}

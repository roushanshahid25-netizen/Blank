﻿using System.ComponentModel.DataAnnotations;
namespace NaatsWebApp.Models
{
    public class NaatKhuwaan
    {
        public string? nkid { get; set; }

        [Required]
        [Display(Name ="Enter Name")]
        public string name { get; set; }

        [Display(Name = "Select Country")]
        public string country { get; set; }
        
        public char gender { get; set; }
        public bool isalive { get; set; }

        [Required(ErrorMessage ="Email must be entered!")]
        [RegularExpression(@"^[^@\s]+@[^@\s]+\.[^@\s]+$",
        ErrorMessage = "Enter a valid email address!")]
        public string email { get; set; }

        [StringLength(8),MinLength(8),MaxLength(8)]
        public string password { get; set; }

        [Compare("password")]
        public string confpassword { get; set; }

        [Range(18,45,ErrorMessage ="Age must between 18-45")]
        public int age { get; set; }

    }
}
